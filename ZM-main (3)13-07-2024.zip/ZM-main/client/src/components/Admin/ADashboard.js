import React, { useState } from 'react';
import '../../styles/ADash.css';

const Sidebar = ({ setActiveSection, isOpen, toggleSidebar }) => {
  return (
    <div className={`sidebar ${isOpen ? 'open' : ''}`}>
      <div className="sidebar-header">
        <button className="toggle-sidebar" onClick={toggleSidebar}>
          <i className={`fas ${isOpen ? 'fa-times' : 'fa-bars'}`}></i>
        </button>
      </div>
      <ul>
        <li><a href="#users" onClick={() => setActiveSection('users')}>Users</a></li>
        <li><a href="#plan-expiry" onClick={() => setActiveSection('plan-expiry')}>Plan Expiry</a></li>
        <li><a href="#payments" onClick={() => setActiveSection('payments')}>Payments</a></li>
        <li><a href="#analytics" onClick={() => setActiveSection('analytics')}>Analytics</a></li>
        <li><a href="#settings" onClick={() => setActiveSection('settings')}>Settings</a></li>
      </ul>
    </div>
  );
}

const UsersSection = () => {
  return (
    <div id="users" className="adsection">
      <h2>Users Section</h2>
    </div>
  );
}

const PlanExpirySection = () => {
  return (
    <div id="plan-expiry" className="adsection">
      <h2>Plan Expiry Section</h2>
    </div>
  );
}

const PaymentsSection = () => {
  return (
    <div id="payments" className="adsection">
      <h2>Payments Section</h2>
    </div>
  );
}

const AnalyticsSection = () => {
  return (
    <div id="analytics" className="adsection">
      <h2>Analytics Section</h2>
    </div>
  );
}

const SettingsSection = () => {
  return (
    <div id="settings" className="adsection">
      <h2>Settings Section</h2>
    </div>
  );
}

const DashboardAdmin = () => {
  const [activeSection, setActiveSection] = useState('users');
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);

  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };

  return (
    <div className="dashboard">
      <Sidebar setActiveSection={setActiveSection} isOpen={isSidebarOpen} toggleSidebar={toggleSidebar} />
      <div className={`amain-content ${isSidebarOpen ? 'open' : ''}`}>
        {activeSection === 'users' && <UsersSection />}
        {activeSection === 'plan-expiry' && <PlanExpirySection />}
        {activeSection === 'payments' && <PaymentsSection />}
        {activeSection === 'analytics' && <AnalyticsSection />}
        {activeSection === 'settings' && <SettingsSection />}
      </div>
    </div>
  );
}

export default DashboardAdmin;