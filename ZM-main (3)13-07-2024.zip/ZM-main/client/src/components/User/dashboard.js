import React, { useState } from 'react';
import '../../styles/UDash.css';

const Sidebar = ({ setActiveSection, isOpen, toggleSidebar }) => {
  return (
    <div className={`sidebar ${isOpen ? 'open' : ''}`}>
      <div className="sidebar-header">
        <button className="toggle-sidebar" onClick={toggleSidebar}>
          <i className={`fas ${isOpen ? 'fa-times' : 'fa-bars'}`}></i>
        </button>
      </div>
      <ul>
        <li><a href="#profile" onClick={() => setActiveSection('profile')}>Profile</a></li>
        <li><a href="#subscription" onClick={() => setActiveSection('subscription')}>Subscription</a></li>
        <li><a href="#billing" onClick={() => setActiveSection('billing')}>Billing</a></li>
        <li><a href="#support" onClick={() => setActiveSection('support')}>Support</a></li>
      </ul>
    </div>
  );
}

const ProfileSection = () => {
  return (
    <div id="profile" className="usection">
      <h2>Profile Section</h2>
      {/* Add content related to user profile */}
    </div>
  );
}

const SubscriptionSection = () => {
  return (
    <div id="subscription" className="usection">
      <h2>Subscription Section</h2>
      {/* Add content related to user subscription */}
    </div>
  );
}

const BillingSection = () => {
  return (
    <div id="billing" className="usection">
      <h2>Billing Section</h2>
      {/* Add content related to user billing */}
    </div>
  );
}

const SupportSection = () => {
  return (
    <div id="support" className="usection">
      <h2>Support Section</h2>
      {/* Add content related to user support */}
    </div>
  );
}

const DashboardUser = () => {
  const [activeSection, setActiveSection] = useState('profile');
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);

  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };

  return (
    <div className="dashboard">
      <Sidebar setActiveSection={setActiveSection} isOpen={isSidebarOpen} toggleSidebar={toggleSidebar} />
      <div className={`umain-content ${isSidebarOpen ? 'open' : ''}`}>
        {activeSection === 'profile' && <ProfileSection />}
        {activeSection === 'subscription' && <SubscriptionSection />}
        {activeSection === 'billing' && <BillingSection />}
        {activeSection === 'support' && <SupportSection />}
      </div>
    </div>
  );
}

export default DashboardUser;