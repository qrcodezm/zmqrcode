import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "../input.css";

const Location = () => {
  const navigate = useNavigate();
  const [locationUrl, setLocationUrl] = useState("");
  const [error, setError] = useState("");

  const handleGenerateQRCode = (e) => {
    e.preventDefault();

    if (!locationUrl) {
      setError("Location URL is required");
      return;
    }

    console.log("Generate QR Code for Google Maps:", locationUrl);
  };

  return (
    <div className="text-container">
      <form onSubmit={handleGenerateQRCode}>
        <label htmlFor="locationUrl">Google Maps Location URL</label>
        <input
          type="text"
          placeholder="Enter Google Maps location URL"
          id="locationUrl"
          value={locationUrl}
          onChange={(e) => setLocationUrl(e.target.value)}
          required
        />
        {error && (
          <div
            style={{ color: "red", marginBottom: "15px", textAlign: "center" }}
          >
            {error}
          </div>
        )}
        <button type="submit">Generate QR Code</button>
      </form>
    </div>
  );
};

export default Location;
