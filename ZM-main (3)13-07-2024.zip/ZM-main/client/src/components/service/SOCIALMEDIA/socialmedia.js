import React, { useState } from "react";
import "../input.css";

const Socialmedia = () => {
  const [socialMediaLinks, setSocialMediaLinks] = useState({
    facebook: "",
    twitter: "",
    linkedin: "",
    instagram: "",
    skype: "",
    youtube: "",
    website: "",
    whatsapp: "",
    email: "",
    telegram: "",
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setSocialMediaLinks((prevLinks) => ({
      ...prevLinks,
      [name]: value,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log(socialMediaLinks);
    // Add QR code generation logic here if needed
  };

  return (
    <div className="text-container">
      <form onSubmit={handleSubmit}>
        <button
          type="button"
          onClick={() =>
            setSocialMediaLinks((prev) => ({ ...prev, facebook: "" }))
          }
        >
          Facebook
        </button>
        {socialMediaLinks.facebook !== undefined && (
          <input
            type="text"
            name="facebook"
            placeholder="www.facebook.com/yourpage"
            value={socialMediaLinks.facebook}
            onChange={handleChange}
          />
        )}

        <button
          type="button"
          onClick={() =>
            setSocialMediaLinks((prev) => ({ ...prev, twitter: "" }))
          }
        >
          Twitter
        </button>
        {socialMediaLinks.twitter !== undefined && (
          <input
            type="text"
            name="twitter"
            placeholder="www.twitter.com/yourpage"
            value={socialMediaLinks.twitter}
            onChange={handleChange}
          />
        )}

        <button
          type="button"
          onClick={() =>
            setSocialMediaLinks((prev) => ({ ...prev, linkedin: "" }))
          }
        >
          LinkedIn
        </button>
        {socialMediaLinks.linkedin !== undefined && (
          <input
            type="text"
            name="linkedin"
            placeholder="www.linkedin.com/yourpage"
            value={socialMediaLinks.linkedin}
            onChange={handleChange}
          />
        )}

        <button
          type="button"
          onClick={() =>
            setSocialMediaLinks((prev) => ({ ...prev, instagram: "" }))
          }
        >
          Instagram
        </button>
        {socialMediaLinks.instagram !== undefined && (
          <input
            type="text"
            name="instagram"
            placeholder="www.instagram.com/yourpage"
            value={socialMediaLinks.instagram}
            onChange={handleChange}
          />
        )}

        <button
          type="button"
          onClick={() =>
            setSocialMediaLinks((prev) => ({ ...prev, skype: "" }))
          }
        >
          Skype
        </button>
        {socialMediaLinks.skype !== undefined && (
          <input
            type="text"
            name="skype"
            placeholder="Skype ID"
            value={socialMediaLinks.skype}
            onChange={handleChange}
          />
        )}

        <button
          type="button"
          onClick={() =>
            setSocialMediaLinks((prev) => ({ ...prev, youtube: "" }))
          }
        >
          YouTube
        </button>
        {socialMediaLinks.youtube !== undefined && (
          <input
            type="text"
            name="youtube"
            placeholder="www.youtube.com/yourpage"
            value={socialMediaLinks.youtube}
            onChange={handleChange}
          />
        )}

        <button
          type="button"
          onClick={() =>
            setSocialMediaLinks((prev) => ({ ...prev, website: "" }))
          }
        >
          Website
        </button>
        {socialMediaLinks.website !== undefined && (
          <input
            type="text"
            name="website"
            placeholder="https://yourwebsite.com"
            value={socialMediaLinks.website}
            onChange={handleChange}
          />
        )}

        <button
          type="button"
          onClick={() =>
            setSocialMediaLinks((prev) => ({ ...prev, whatsapp: "" }))
          }
        >
          WhatsApp
        </button>
        {socialMediaLinks.whatsapp !== undefined && (
          <input
            type="text"
            name="whatsapp"
            placeholder="https://wa.me/phonenumber"
            value={socialMediaLinks.whatsapp}
            onChange={handleChange}
          />
        )}

        <button
          type="button"
          onClick={() =>
            setSocialMediaLinks((prev) => ({ ...prev, email: "" }))
          }
        >
          Email
        </button>
        {socialMediaLinks.email !== undefined && (
          <input
            type="text"
            name="email"
            placeholder="abc@domain.com"
            value={socialMediaLinks.email}
            onChange={handleChange}
          />
        )}

        <button
          type="button"
          onClick={() =>
            setSocialMediaLinks((prev) => ({ ...prev, telegram: "" }))
          }
        >
          Telegram
        </button>
        {socialMediaLinks.telegram !== undefined && (
          <input
            type="text"
            name="telegram"
            placeholder="https://t.me/username"
            value={socialMediaLinks.telegram}
            onChange={handleChange}
          />
        )}
      </form>
    </div>
  );
};

export default Socialmedia;
