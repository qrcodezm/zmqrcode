import React, { useState } from 'react';
import '../input.css';

const WiFi = () => {
    const [ssid, setSsid] = useState('');
    const [securityType, setSecurityType] = useState('WPA');
    const [password, setPassword] = useState('');
    const [hidden, setHidden] = useState(false);
    const [error, setError] = useState('');
    const [wifiConfig, setWifiConfig] = useState('');

    const handleSubmit = (e) => {
        e.preventDefault();

        if (!ssid) return setError('SSID is required');
        if (securityType !== 'nopass' && !password) return setError('Password is required');

        setError('');

        const config = `WIFI:S:${ssid};T:${securityType};P:${password};H:${hidden ? 'true' : ''};;`;
        setWifiConfig(config);
    }

    return (
        <div className='text-container'>
            <form onSubmit={handleSubmit}>
                <label htmlFor='ssid'>SSID</label>
                <input
                    type='text'
                    placeholder='SSID'
                    id='ssid'
                    value={ssid}
                    onChange={(e) => setSsid(e.target.value)}
                />
                <label htmlFor='securityType'>Security Type</label>
                <select
                    id='securityType'
                    value={securityType}
                    onChange={(e) => setSecurityType(e.target.value)}
                >
                    <option value='WEP'>WEP</option>
                    <option value='WPA'>WPA</option>
                    <option value='nopass'>No Password</option>
                </select>
                {securityType !== 'nopass' && (
                    <>
                        <label htmlFor='password'>Password</label>
                        <input
                            type='password'
                            placeholder='Password'
                            id='password'
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                        />
                    </>
                )}
                <div className='checkbox-container'>
                    <label>Hidden Network</label>
                    <input
                        type='checkbox'
                        checked={hidden}
                        onChange={(e) => setHidden(e.target.checked)}
                    />
                </div>
                {error && <div style={{ color: 'red', marginBottom: '15px', textAlign: 'center' }}>{error}</div>}
                <button>Generate Qr</button>
                <button type='submit'>Submit</button>
            </form>
        </div>
    )
}

export default WiFi;
