import React, { useState } from "react";
import "../input.css";

const UPIComponent = () => {
  const [upiId, setUpiId] = useState("");
  const [payeeName, setPayeeName] = useState("");
  const [amount, setAmount] = useState("");
  const [remark, setRemark] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log({
      upiId,
      payeeName,
      amount,
      remark,
    });
    // Add UPI payment processing logic here if needed
  };

  return (
    <div className="text-container">
      <form onSubmit={handleSubmit}>
        <label htmlFor="upiId">UPI ID / VPA</label>
        <input
          type="text"
          id="upiId"
          placeholder="Your UPI ID / VPA"
          value={upiId}
          onChange={(e) => setUpiId(e.target.value)}
          required
        />

        <label htmlFor="payeeName">Payee Name</label>
        <input
          type="text"
          id="payeeName"
          placeholder="Payee Name"
          value={payeeName}
          onChange={(e) => setPayeeName(e.target.value)}
          required
        />

        <label htmlFor="currency">Currency</label>
        <input type="text" id="currency" value="INR" readOnly />

        <label htmlFor="amount">Amount</label>
        <input
          type="text"
          id="amount"
          placeholder="Enter Amount"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          required
        />

        <label htmlFor="remark">Transaction Remark</label>
        <textarea
          id="remark"
          placeholder="Enter Transaction Remark"
          value={remark}
          onChange={(e) => setRemark(e.target.value)}
        />

        <button type="submit">Submit</button>
      </form>
    </div>
  );
};

export default UPIComponent;
