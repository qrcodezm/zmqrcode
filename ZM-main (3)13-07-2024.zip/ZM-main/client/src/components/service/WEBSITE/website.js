import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "../input.css";

const Website = () => {
  const navigate = useNavigate();
  const [url, setUrl] = useState("");
  const [error, setError] = useState("");

  const isValidWebsite = (url) => {
    const pattern = /^(https?:\/\/)?([a-zA-Z0-9.-]+)(:[0-9]{1,5})?(\/.*)?$/;
    return pattern.test(url);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!url) {
      return setError("URL is required");
    }

    if (!isValidWebsite(url)) {
      return setError(
        "Please enter a valid website URL (e.g., https://www.example.com)"
      );
    }

    setError("");
    navigate("/dashboard");
  };

  return (
    <div className="text-container">
      <form>
        <label htmlFor="url">Website URL</label>
        <input
          type="text"
          placeholder="https://www.example.com"
          id="url"
          value={url}
          onChange={(e) => setUrl(e.target.value)}
          required
        />
        {error && (
          <div
            style={{ color: "red", marginBottom: "15px", textAlign: "center" }}
          >
            {error}
          </div>
        )}
        <button onClick={(e) => handleSubmit(e)}>Generate QR Code</button>
      </form>
    </div>
  );
};

export default Website;
