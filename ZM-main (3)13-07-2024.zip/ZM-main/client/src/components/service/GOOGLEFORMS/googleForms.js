import React, { useState } from 'react';
import QRCode from 'qrcode';
import '../input.css';

const GoogleFormsUploadForm = () => {
    const [formUrl, setFormUrl] = useState('');
    const [qrCodeData, setQrCodeData] = useState('');
    const [styleOption, setStyleOption] = useState('default');
    const [error, setError] = useState('');

    const handleInputChange = (e) => {
        setFormUrl(e.target.value);
    };

    const generateQRCode = async () => {
        if (!formUrl) {
            setError('Please enter a Google Docs URL');
            return;
        }
        try {
            const data = await QRCode.toDataURL(formUrl, {
                color: {
                    dark: styleOption === 'dark' ? '#000000' : '#0000FF',
                    light: '#FFFFFF'
                },
            });
            setQrCodeData(data);
            setError('');
        } catch (error) {
            console.error('Error generating QR code:', error);
            setError('Failed to generate QR code');
        }
    };

    return (
        <div className='qr-code-form'>
            <div className='url-container'>
                <label htmlFor='formUrl'>Google Docs URL</label>
                <input
                    type='url'
                    placeholder='Enter Google Forms URL'
                    value={formUrl}
                    onChange={handleInputChange}
                    id='formUrl'
                    required
                />
            </div>

            <div className='style-options'>
                <label htmlFor='style-select'>Select QR Code Style:</label>
                <select
                    id='style-select'
                    value={styleOption}
                    onChange={(e) => setStyleOption(e.target.value)}
                >
                    <option value='default'>Default</option>
                    <option value='dark'>Dark</option>
                </select>
            </div>

            <button onClick={generateQRCode}>Generate QR Code</button>

            {error && <div style={{ color: 'red', marginBottom: '15px', textAlign: 'center' }}>{error}</div>}
            {qrCodeData && (
                <div className='qr-code'>
                    <img src={qrCodeData} alt='QR Code' />
                </div>
            )}
        </div>
    );
};

export default GoogleFormsUploadForm;
