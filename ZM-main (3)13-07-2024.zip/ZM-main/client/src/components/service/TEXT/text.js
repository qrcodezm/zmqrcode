import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "../input.css";

const Text = () => {
  const navigate = useNavigate();
  const [text, setText] = useState("");
  const [error, setError] = useState("");

  const handleGenerateQRCode = (e) => {
    e.preventDefault();

    if (!text) return setError("Text is required");

    console.log("Generate QR Code for:", text);
  };

  return (
    <div className="text-container">
      <form onSubmit={handleGenerateQRCode}>
        <label htmlFor="text">Text</label>
        <input
          type="text"
          placeholder="Enter text"
          id="text"
          value={text}
          onChange={(e) => setText(e.target.value)}
          required
        />
        {error && (
          <div
            style={{ color: "red", marginBottom: "15px", textAlign: "center" }}
          >
            {error}
          </div>
        )}
        <button type="submit">Generate QR Code</button>
      </form>
    </div>
  );
};

export default Text;
