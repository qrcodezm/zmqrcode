import React, { useState } from 'react';
import '../input.css';

const GenerateQR = ({ options, setOptions }) => {
    const [styleOption, setStyleOption] = useState('default');

    const handleOptions = (e) => {
        e.preventDefault();
        setOptions({
            color: {
                dark: styleOption === 'default' ? '#000' : '#00f',
                light: '#FFFFFF'
            },
            errorCorrectionLevel: 'Q'
        })
    }

    return (
        <>
            <div className='text-container'>
                <form>
                    <label htmlFor='style-select'>Select QR Code Style:</label>
                    <select
                        id='style-select'
                        value={styleOption}
                        onChange={(e) => setStyleOption(e.target.value)}
                    >
                        <option value='default'>Default</option>
                        <option value='blue'>Blue</option>
                    </select>

                    <button onClick={handleOptions}>Generate QR Code</button>
                </form>
            </div>
        </>
    )
}

export default GenerateQR