import React, { useEffect, useState } from 'react';
import QRCode from 'qrcode';
import '../input.css';

const URL = 'zmqrcode.com';
const options = {
    color: {
        dark: '#000000',
        light: '#FFFFFF'

    }
}

const QR = ({ url = URL, Options = options }) => {
    const [qrCodeData, setQrCodeData] = useState('');
    const [error, setError] = useState('');

    useEffect(() => {
        generateQRCode();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [Options, url])

    const generateQRCode = async () => {
        try {
            const data = await QRCode.toDataURL(url, Options);
            setQrCodeData(data);
        } catch (error) {
            console.error('Error generating QR code:', error);
            setError('Failed to generate QR code');
        }
    };

    return (
        <div className='qr-container'>
            {qrCodeData && (
                <div>
                    <img src={qrCodeData} height={280} alt='QR Code' />
                </div>
            )}
            {error && <div style={{ color: 'red', marginBottom: '15px', textAlign: 'center' }}>{error}</div>}
        </div>
    )
}

export default QR