import React, { useState } from 'react';
import GenerateQR from './generateQR';
import QR from './QR';
import { Outlet } from 'react-router-dom';
import './QRLayout.css'

const QRLayout = () => {
    const [options, setOptions] = useState({});

    return (
        <div className='qr-layout'>
            <div className='qr-form'>
                <Outlet />
                <GenerateQR options={options} setOptions={setOptions} />
            </div>
            <div className='qr'>
                <QR Options={options} />
            </div>
        </div>
    )
}

export default QRLayout