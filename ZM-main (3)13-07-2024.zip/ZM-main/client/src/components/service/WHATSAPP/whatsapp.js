import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "../input.css";

const WhatsAppURL = () => {
  const navigate = useNavigate();
  const [url, setUrl] = useState("");
  const [error, setError] = useState("");

  const isValidWhatsAppURL = (url) => {
    const pattern = /^https:\/\/wa\.me\/[0-9]+$/;
    return pattern.test(url);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!url) {
      return setError("URL is required");
    }

    if (!isValidWhatsAppURL(url)) {
      return setError(
        "Please enter a valid WhatsApp URL (e.g., https://wa.me/1234567890)"
      );
    }

    setError("");
    navigate("/dashboard");
  };

  return (
    <div className="text-container">
      <form>
        <label htmlFor="url">WhatsApp URL</label>
        <input
          type="text"
          placeholder="https://wa.me/1234567890"
          id="url"
          value={url}
          onChange={(e) => setUrl(e.target.value)}
          required
        />
        {error && (
          <div
            style={{ color: "red", marginBottom: "15px", textAlign: "center" }}
          >
            {error}
          </div>
        )}
        <button onClick={(e) => handleSubmit(e)}>Submit</button>
      </form>
    </div>
  );
};

export default WhatsAppURL;
