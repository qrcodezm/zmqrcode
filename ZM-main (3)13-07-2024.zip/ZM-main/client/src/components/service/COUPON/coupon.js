import React, { useState } from "react";
import "../input.css";

const Coupon = () => {
  const [companyName, setCompanyName] = useState("");
  const [headline, setHeadline] = useState("");
  const [description, setDescription] = useState("");
  const [saleBadge, setSaleBadge] = useState("");
  const [couponID, setCouponID] = useState("");
  const [validDate, setValidDate] = useState("");
  const [terms, setTerms] = useState("");
  const [buttonName, setButtonName] = useState("");
  const [buttonLink, setButtonLink] = useState("");
  const [address, setAddress] = useState("");
  const [website, setWebsite] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log({
      companyName,
      headline,
      description,
      saleBadge,
      couponID,
      validDate,
      terms,
      buttonName,
      buttonLink,
      address,
      website,
    });
    // Add QR code generation logic here if needed
  };

  return (
    <div className="text-container">
      <form onSubmit={handleSubmit}>
        <label htmlFor="companyName">Company Name</label>
        <input
          type="text"
          id="companyName"
          placeholder="Your company name"
          value={companyName}
          onChange={(e) => setCompanyName(e.target.value)}
          required
        />

        <label htmlFor="headline">Headline</label>
        <input
          type="text"
          id="headline"
          placeholder="Your page headline"
          value={headline}
          onChange={(e) => setHeadline(e.target.value)}
          required
        />

        <label htmlFor="description">Description</label>
        <textarea
          id="description"
          placeholder="Your page summary"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          required
        />

        <label htmlFor="saleBadge">Sale Badge</label>
        <input
          type="text"
          id="saleBadge"
          placeholder="50% OFF"
          value={saleBadge}
          onChange={(e) => setSaleBadge(e.target.value)}
          required
        />

        <label htmlFor="couponID">Coupon ID</label>
        <input
          type="text"
          id="couponID"
          placeholder="Eg. SALE50OFF"
          value={couponID}
          onChange={(e) => setCouponID(e.target.value)}
          required
        />

        <label htmlFor="validDate">Valid</label>
        <input
          type="date"
          id="validDate"
          value={validDate}
          onChange={(e) => setValidDate(e.target.value)}
          required
        />

        <label htmlFor="terms">Terms & Conditions</label>
        <textarea
          id="terms"
          placeholder="Type your Terms & Conditions"
          value={terms}
          onChange={(e) => setTerms(e.target.value)}
          required
        />

        <label htmlFor="buttonName">Button Name</label>
        <input
          type="text"
          id="buttonName"
          placeholder="Get it Now!"
          value={buttonName}
          onChange={(e) => setButtonName(e.target.value)}
          required
        />

        <label htmlFor="buttonLink">Button Link</label>
        <input
          type="url"
          id="buttonLink"
          placeholder="www.YourWebsite.com/buy"
          value={buttonLink}
          onChange={(e) => setButtonLink(e.target.value)}
          required
        />

        <label htmlFor="address">Address</label>
        <textarea
          id="address"
          placeholder="Your page summary"
          value={address}
          onChange={(e) => setAddress(e.target.value)}
          required
        />

        <label htmlFor="website">My Website</label>
        <input
          type="url"
          id="website"
          placeholder="www.yourweburl.com"
          value={website}
          onChange={(e) => setWebsite(e.target.value)}
          required
        />
      </form>
    </div>
  );
};

export default Coupon;
