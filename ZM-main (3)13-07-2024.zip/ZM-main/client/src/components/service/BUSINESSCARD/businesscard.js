import React, { useState } from "react";
import "../input.css";

const BusinessCard = () => {
  const [profilePhoto, setProfilePhoto] = useState(null);
  const [brandLogo, setBrandLogo] = useState(null);
  const [name, setName] = useState("");
  const [title, setTitle] = useState("");
  const [company, setCompany] = useState("");
  const [contactNumber, setContactNumber] = useState("");
  const [email, setEmail] = useState("");
  const [address, setAddress] = useState("");
  const [pageURL, setPageURL] = useState("");
  const [error, setError] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!pageURL || pageURL.length < 5) {
      return setError(
        "Page URL is required and must be at least 5 characters."
      );
    }

    setError("");
    console.log({
      profilePhoto,
      brandLogo,
      name,
      title,
      company,
      contactNumber,
      email,
      address,
      pageURL,
    });
    // Add QR code generation logic here
  };

  return (
    <div className="text-container">
      <form onSubmit={handleSubmit}>
        <label htmlFor="pageURL">
          Your Page URL (Once saved, cannot be changed later)
        </label>
        <input
          type="text"
          id="pageURL"
          placeholder="enter your business url"
          value={pageURL}
          onChange={(e) => setPageURL(e.target.value)}
          required
        />
        <p>*minimum 5 characters required</p>

        <label htmlFor="profilePhoto">Profile Photo (400x500px, 4:5)</label>
        <input
          type="file"
          id="profilePhoto"
          onChange={(e) => setProfilePhoto(e.target.files[0])}
        />

        <label htmlFor="brandLogo">Brand Logo (160x80px, 3:1)</label>
        <input
          type="file"
          id="brandLogo"
          onChange={(e) => setBrandLogo(e.target.files[0])}
        />

        <label htmlFor="name">Name</label>
        <input
          type="text"
          id="name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          required
        />

        <label htmlFor="title">Title</label>
        <input
          type="text"
          id="title"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          required
        />

        <label htmlFor="company">Company</label>
        <input
          type="text"
          id="company"
          value={company}
          onChange={(e) => setCompany(e.target.value)}
          required
        />

        <label htmlFor="contactNumber">Contact Number</label>
        <input
          type="text"
          id="contactNumber"
          value={contactNumber}
          onChange={(e) => setContactNumber(e.target.value)}
          required
        />

        <label htmlFor="email">Email</label>
        <input
          type="email"
          id="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
        />

        <label htmlFor="address">Address</label>
        <input
          type="text"
          id="address"
          value={address}
          onChange={(e) => setAddress(e.target.value)}
          required
        />

        {error && (
          <div
            style={{ color: "red", marginBottom: "15px", textAlign: "center" }}
          >
            {error}
          </div>
        )}
      </form>
    </div>
  );
};

export default BusinessCard;
