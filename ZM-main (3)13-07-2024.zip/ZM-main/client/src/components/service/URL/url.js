import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import '../input.css';

const URL = () => {
    const navigate = useNavigate();
    const [url, setUrl] = useState('');
    const [error, setError] = useState('');

    const handleSubmit = async (e) => {
        e.preventDefault();

        if (!url) return setError('url is required');

        navigate('/dashboard');
    }

    return (
        <div className='text-container'>
            <form>
                <label htmlFor='url'>URL</label>
                <input
                    type='text'
                    placeholder='url'
                    id='url'
                    value={url}
                    onChange={(e) => setUrl(e.target.value)}
                    required
                />
                {error && <div style={{ color: 'red', marginBottom: '15px', textAlign: 'center' }}>{error}</div>}
                <button onClick={(e) => handleSubmit(e)}>Submit</button>
            </form>
        </div>
    )
}

export default URL