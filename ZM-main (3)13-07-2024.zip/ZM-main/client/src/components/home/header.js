import React from 'react';
import '../../styles/header.css';
import { useNavigate } from 'react-router-dom';

const Header = () => {
    const navigate = useNavigate();
    return (
        <div className='header' id='header'>
            <div className='hcontent'>
            <div className='tail'>
                <button onClick={() => navigate('/login')}>login</button>
            </div>
                <div className='head'>
                    <button onClick={() => navigate('/services')}>Generate your QR code</button>
                </div>
            </div>
        </div>
    );
}

export default Header;
