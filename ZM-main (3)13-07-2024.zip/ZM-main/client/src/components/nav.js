import React, { useState, useEffect } from "react";
import "../styles/nav.css";
import { Outlet, Link, useNavigate, useLocation } from "react-router-dom";
import { HashLink } from "react-router-hash-link";
import Footer from "./home/footer";
import { jwtDecode } from "jwt-decode";
import axios from "../api/axios";

const Nav = () => {
  const navigate = useNavigate();
  const [toggle, setToggle] = useState(false);

  const { pathname } = useLocation();

  useEffect(() => {
    if (toggle === true) setToggle(false);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pathname]);

  const accessToken = localStorage.getItem("accessToken");
  let decoded,
    logged = false;
  if (accessToken) {
    decoded = jwtDecode(accessToken);
    logged = true;

    const exp = decoded?.exp;
    if (Date.now() >= exp * 1000) {
      logged = false;
    }
  }
  const [signed, setSigned] = useState(logged);

  const logout = async () => {
    try {
      const accessToken = localStorage.getItem("accessToken");
      const decoded = jwtDecode(accessToken);
      await axios.post("/logout", { role: decoded.userInfo.role });
      localStorage.removeItem("accessToken");
      setSigned(false);
      window.location.reload();
      console.log("success", "Successfully logged out");
    } catch (err) {
      console.log("failed", err?.response?.data?.message);
    }
    navigate("/");
  };

  return (
    <>
      <div className="nav" id="nav">
        <div className="toggle-logo">
          <button
            onClick={() => setToggle(!toggle)}
            className="nav-toggle"
            id="nav-toggle"
          >
            &#9776;
          </button>
          <div className="logo" onClick={() => navigate("/")}>
            <img src="/nav/nav-zm.png" height={80} alt="zm-logo" />
            <div>
              <p className="zm-name">zmqrcode.com</p>
              <p>Your Security is Our Priority</p>
            </div>
          </div>
        </div>

        <ul className={`nav-items ${toggle ? "active" : ""}`}>
          <li>
            <HashLink smooth to="/#header" onClick={() => setToggle(false)}>
              Home
            </HashLink>
          </li>
          <li>
            <Link to="/aboutqr" onClick={() => setToggle(false)}>
              About QR
            </Link>
          </li>
          <li>
            <Link to="/aboutus" onClick={() => setToggle(false)}>
              About ZM
            </Link>
          </li>
          <li>
            <Link to="/services" onClick={() => setToggle(false)}>
              Services
            </Link>
          </li>
          <li>
            <Link to="/pricing" onClick={() => setToggle(false)}>
              Pricing
            </Link>
          </li>
          {signed ? (
            <>
              <li className="auth" onClick={() => setToggle(false)}>
                <Link onClick={logout}>Logout</Link>
              </li>
            </>
          ) : (
            <>
              <li>
                <HashLink smooth to="/#faq" onClick={() => setToggle(false)}>
                  FAQ
                </HashLink>
              </li>
              <li>
                <HashLink
                  smooth
                  to="/#contact"
                  onClick={() => setToggle(false)}
                >
                  Contact us
                </HashLink>
              </li>
              <li className="auth">
                <Link to="/login" onClick={() => setToggle(false)}>
                  Login
                </Link>
              </li>
            </>
          )}
        </ul>
      </div>
      <div style={{ minHeight: "90vh" }}>
        <Outlet />
      </div>
      <Footer />
    </>
  );
};

export default Nav;
