import React from 'react';
import '../../styles/pricing.css';

const PricingPage = () => {
  const enterprisePrices = [
    { range: "Required Storage Database", price: "The intention of discussing a possible price for industries benfit" },
  ];

  const individualPrices = [
    { range: "0 to 100 MB", price: "199/-" },
    { range: "0 to 250 MB", price: "299/-" },
    { range: "0 to 500 MB", price: "499/-" },
    { range: "0 to 1 GB", price: "999/-" },
    { range: "0 to 2 GB", price: "1599/-" },
    { range: "0 to 3 GB", price: "1999/-" },
    { range: "0 to 5 GB", price: "2999/-" },
    { range: "0 to 10 GB", price: "5999/-" },
    { range: "0 to 15 GB", price: "9999/-" },
    { range: "0 to 20 GB", price: "12999/-" },
    { range: "0 to 25 GB", price: "15999/-" },
    { range: "0 to 30 GB", price: "19999/-" },
    { range: "0 to 35 GB", price: "22999/-" },
    { range: "0 to 40 GB", price: "25999/-" },
    { range: "0 to 50 GB", price: "29999/-" },
    { range: "0 to 60 GB", price: "34999/-" },
    { range: "0 to 70 GB", price: "39999/-" },
    { range: "0 to 80 GB", price: "44999/-" },
    { range: "0 to 90 GB", price: "49999/-" },
    { range: "0 to 1 TB", price: "54999/-" },
  ];

  return (
    <div className="pricing-page">
      <h1 className="title">Pricing Plans</h1>
      <div className="pricing-section">
        <h2 className="category-title">Industry</h2>
        <table className="pricing-table">
          <thead>
            <tr>
              <th>Storage</th>
              <th>Price</th>
            </tr>
          </thead>
          <tbody>
            {enterprisePrices.map((item, index) => (
              <tr key={index}>
                <td>{item.range}</td>
                <td>{item.price}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="pricing-section">
        <h2 className="category-title">Individual</h2>
        <table className="pricing-table">
          <thead>
            <tr>
              <th>Storage</th>
              <th>Price</th>
            </tr>
          </thead>
          <tbody>
            {individualPrices.map((item, index) => (
              <tr key={index}>
                <td>{item.range}</td>
                <td>{item.price}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default PricingPage;
