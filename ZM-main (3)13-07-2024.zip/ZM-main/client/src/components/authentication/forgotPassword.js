import React, { useState } from 'react';
import axios from '../../api/axios';
import '../../styles/loginPage.css';

const ForgotPassword = () => {
  const [email, setEmail] = useState('');
  const [success, setSuccess] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();

    setError('');
    try {
      setLoading(true);
      const response = await axios.post('/forget', { mail: email });
      const res = response?.data;
      setSuccess(res.success);
      localStorage.setItem('forgetToken', res.token);

      console.log(success);
      setEmail('');
    } catch (err) {
      const errorMessage = err?.response?.data?.message || err?.message || 'error fetching server information';
      setError(errorMessage);
      console.log(err)
    }
    finally {
      setLoading(false);
    }
  };

  return (
    <div className="body-login">
      <img className='login-people' src='/contact/contact-people.png' height={700} alt='people' />
      <div className='login-container'>
        <h2>Forgot Password</h2>
        {error && <div style={{ color: 'red', marginBottom: '15px', textAlign: 'center' }}>{error}</div>}
        <form onSubmit={handleSubmit}>
          <div>
            <label htmlFor='f-email'>Email</label>
            <input
              type="email"
              id='f-email'
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>
          <button type="submit">
            {loading ? <span className="spinner" /> : 'Submit'}
          </button>
        </form>
      </div>
    </div>
  );
};

export default ForgotPassword;
