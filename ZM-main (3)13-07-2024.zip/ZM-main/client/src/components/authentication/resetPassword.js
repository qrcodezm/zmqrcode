import React, { useState } from 'react';
import axios from '../../api/axios';
import { useNavigate } from 'react-router-dom';
import '../../styles/loginPage.css';

const ResetPassword = () => {
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [success, setSuccess] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();

    setError('');
    if (password === confirmPassword) {
      const token = localStorage.getItem('forgetToken');
      if (!token || token.length === 0) return setError('send forget mail request first');

      try {
        setLoading(true);
        const response = await axios.post('/reset', { token, newPassword: password });
        const res = response?.data;
        setSuccess(res.success);

        navigate('/login');
        console.log(success);
        setPassword('');
        setConfirmPassword('');
      } catch (err) {
        const errorMessage = err?.response?.data?.message || err?.message || 'error fetching server information';
        setError(errorMessage);
        console.log(err)
      } finally {
        setLoading(false);
      }
    } else {
      setError("Passwords do not match");
    }
  };

  return (
    <div className="body-login">
      <img className='login-people' src='/contact/contact-people.png' height={700} alt='people' />
      <div className='login-container'>
        {error && <div style={{ color: 'red', marginBottom: '15px', textAlign: 'center' }}>{error}</div>}
        <h2>Reset Password</h2>
        <form onSubmit={handleSubmit}>
          <div>
            <label>New Password</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>
          <div>
            <label>Confirm Password</label>
            <input
              type="password"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              required
            />
          </div>
          <button type="submit">
            {loading ? <span className="spinner" /> : 'Submit'}
          </button>
        </form>
      </div>
    </div>
  );
};

export default ResetPassword;
