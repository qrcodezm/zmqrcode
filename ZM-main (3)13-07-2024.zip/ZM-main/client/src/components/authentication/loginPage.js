import React, { useState } from 'react';
import axios from '../../api/axios';
import '../../styles/loginPage.css'
import { Link, useNavigate } from 'react-router-dom';

const LoginPage = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const navigate = useNavigate();

  const handleSubmit = async (event) => {
    event.preventDefault();
    console.log(username, password, role)
    setError('');
    try {
      setLoading(true);
      const response = await axios.post('/login', { username, password, role });
      const accessToken = response?.data?.accessToken;
      console.log(accessToken);
      localStorage.setItem('accessToken', accessToken);

      navigate('/');
      window.location.reload();

      setUsername('');
      setPassword('');
    } catch (err) {
      const errorMessage = err?.response?.data?.message || err?.message || 'error fetching server information';
      setError(errorMessage);
      console.log(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="body-login">
      <img className='login-people' src='/contact/contact-people.png' height={700} alt='people' />
      <div className='login-container'>
        <h2>Login</h2>
        {error && <div style={{ color: 'red', marginBottom: '15px', textAlign: 'center' }}>{error}</div>}
        <form onSubmit={handleSubmit}>
          <div>
            <label htmlFor="username">Username</label>
            <input
              type="text"
              id="username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              required
            />
          </div>
          <div>
            <label htmlFor="password">Password</label>
            <input
              type="password"
              id="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>
          <div>
            <label htmlFor='role'>Role</label>
            <select id='role' required value={role} onChange={(e) => setRole(e.target.value)}>
              <option></option>
              <option>user</option>
              <option>admin</option>
            </select>
          </div>
          <button type="submit" disabled={loading}>
            {loading ? <span className="spinner" /> : 'Login'}
          </button>
        </form>
        <div className="links">
          <Link to={'/forget'}>Forgot Password?</Link>
          <Link to={'/signup'}>Register</Link>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;
