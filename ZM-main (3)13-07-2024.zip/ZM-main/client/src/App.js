import React from "react";
import { Routes, Route } from "react-router-dom";
import { jwtDecode } from "jwt-decode";
import RegistrationForm from "./components/authentication/registration";
import LoginPage from "./components/authentication/loginPage";
import Nav from "./components/nav";
import NotFound from "./components/notFound";
import Home from "./components/home/home";
import AboutQr from "./components/AboutQr/AboutQr";
import ForgotPassword from "./components/authentication/forgotPassword";
import ResetPassword from "./components/authentication/resetPassword";
import ViewAll from "./components/service/viewall";
import PricingPage from "./components/Pricing/pricing";
import AboutUS from "./components/AboutUS/AboutUS";
import TermsOfService from "./components/terms&policies/Terms";
import DashboardAdmin from "./components/Admin/ADashboard";
import DashboardUser from "./components/User/dashboard";
import URL from "./components/service/URL/url";
import WiFi from "./components/service/WIFI/wifi";
import VideoUploadForm from "./components/service/VIDEO/video";
import ImageUploadForm from "./components/service/IMAGE/image";
import DocumentUploadForm from "./components/service/DOCUMENT/docs";
import AudioUploadForm from "./components/service/AUDIO/audio";
import GoogleFormsUpload from "./components/service/GOOGLEFORMS/googleForms";
import MenuCardUploadForm from "./components/service/MENUCARD/menu";
import PptUploadForm from "./components/service/PPT/ppt";
import ComingSoon from "./components/comingsoon";
import QRLayout from "./components/service/QRGeneration/QRLayout";
import WhatsAppURL from "./components/service/WHATSAPP/whatsapp";
import Text from "./components/service/TEXT/text";
import Location from "./components/service/LOCATION/location";
import Website from "./components/service/WEBSITE/website";
import BusinessCard from "./components/service/BUSINESSCARD/businesscard";
import Coupon from "./components/service/COUPON/coupon";
import UPI from "./components/service/UPI/upi";
import Socialmedia from "./components/service/SOCIALMEDIA/socialmedia";
import Facebook from "./components/service/FACEBOOK/facebook";
import Youtube from "./components/service/YOUTUBE/youtube";
import Zoommeeting from "./components/service/ZOOMMEETING/zoommeeting";
import Googlemeet from "./components/service/GOOGLEMEET/googlemeet";
import Meeting from "./components/service/MEETING/meeting";

const App = () => {
  const accessToken = localStorage.getItem("accessToken");
  let decoded, role = "";
  if (accessToken) {
    decoded = jwtDecode(accessToken);

    const exp = decoded?.exp;
    if (Date.now() <= exp * 1000) {
      role = decoded?.userInfo.role || "";
    }
  }

  return (
    <Routes>
      <Route path="/" element={<Nav />}>
        {/* public routes */}
        <Route index={role === "" ? true : false} element={<Home />} />
        <Route path="login" element={<LoginPage />} />
        <Route path="signup" element={<RegistrationForm />} />
        <Route path="forget" element={<ForgotPassword />} />
        <Route path="reset" element={<ResetPassword />} />
        <Route path="aboutqr" element={<AboutQr />} />
        <Route path="aboutus" element={<AboutUS />} />
        <Route path="services">
          <Route index element={<ViewAll />} />
          {/* services */}

          <Route element={<QRLayout />}>
            <Route path="video" element={<VideoUploadForm />} />
            <Route path="image-gallery" element={<ImageUploadForm />} />
            <Route path="audio" element={<AudioUploadForm />} />
            <Route path="docs" element={<DocumentUploadForm />} />
            <Route path="google-forms" element={<GoogleFormsUpload />} />
            <Route path="menu" element={<MenuCardUploadForm />} />
            <Route path="ppt" element={<PptUploadForm />} />
            <Route path="links" element={<URL />} />
            <Route path="wifi" element={<WiFi />} />

            <Route path="website" element={<Website />} />
            <Route path="businesscard" element={<BusinessCard />} />
            <Route path="coupon" element={<Coupon />} />
            <Route path="whatsapp" element={<WhatsAppURL />} />
            <Route path="text" element={<Text />} />
            <Route path="location" element={<Location />} />
            <Route path="upi" element={<UPI />} />
            <Route path="socialmedia" element={<Socialmedia />} />
            <Route path="facebook" element={<Facebook />} />
            <Route path="youtube" element={<Youtube />} />
            <Route path="zoommeeting" element={<Zoommeeting />} />
            <Route path="googlemeet" element={<Googlemeet />} />
            <Route path="meeting" element={<Meeting />} />
          </Route>
          <Route path="coming-soon" element={<ComingSoon />} />
        </Route>


        <Route path="pricing" element={<PricingPage />} />
        {/* terms */}
        <Route path="Terms" element={<TermsOfService />} />
        <Route path="PP" element={<TermsOfService />} />
        <Route path="CP" element={<TermsOfService />} />

        {/* role-based dashboards */}
        {role === "admin" && (
          <Route
            index={role === "admin" ? true : false}
            element={<DashboardAdmin />}
          />
        )}
        {role === "user" && (
          <Route
            index={role === "admin" ? true : false}
            element={<DashboardUser />}
          />
        )}

        {/* catch all */}
        <Route path="*" element={<NotFound />} />
      </Route>
    </Routes>
  );
};

export default App;
