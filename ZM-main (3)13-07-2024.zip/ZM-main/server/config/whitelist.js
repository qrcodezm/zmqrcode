const whitelist = [
    'https://www.google.com',
    'http://localhost:3500',
    'http://localhost:3000'
];

module.exports = whitelist;