const mongoose = require('mongoose');
const { Schema } = mongoose;

const urlSchema = new Schema({
    url: {
        type: String,
        required: true
    },
    user: {
        type: Schema.Types.ObjectId,
        ref: 'User',
        required: true
    }
});

module.exports = {
    URL: mongoose.model('URL', urlSchema)
};