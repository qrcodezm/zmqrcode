const mongoose = require('mongoose');
const { Schema } = mongoose;

const newsletterSchema = new Schema({
    mail: {
        type: String,
        required: true
    }
});

module.exports = mongoose.model('Newsletter', newsletterSchema);