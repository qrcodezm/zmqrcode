const User = require('../models/user');
const URL = require('../models/services').URL;

const handleUrl = async (req, res, next) => {
    const { url } = req.body;
    if (!url || url.length === 0) return res.status(400).json({ 'message': 'url should not be empty' });
    const { user } = req.user;

    try {
        const foundUser = await User.findOne({ username: user }).exec();
        if (!foundUser) return res.status(400).json({ 'message': 'Bad request - User not found' });

        const query = URL.create({
            url,
            user: foundUser._id
        });

        await query.save();

        res.json({ 'Success': 'Sucessfully stored url' });

    } catch (err) {
        next(err);
    }

};

module.exports = {
    handleUrl
}