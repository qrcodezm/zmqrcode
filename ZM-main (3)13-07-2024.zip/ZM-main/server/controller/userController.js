const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const nodemailer = require('nodemailer');
const Contact = require('../models/contact');
const Newsletter = require('../models/newsletter');

const handleLogin = async (req, res) => {
    const cookies = req.cookies;
    const { username, password, role } = req.body;
    if (!username || !password) return res.status(400).json({ 'message': 'Bad request - Username and Password are required' });
    if (!role) return res.status(400).json({ 'message': 'Bad request - role is required' });
    if (!['user', 'admin'].includes(role)) return res.status(400).json({ 'message': 'invalid role' });

    const User = require('../models/' + role);
    const foundUser = await User.findOne({ username }).exec();
    if (!foundUser) return res.status(401).json({ 'message': 'unauthorized' });

    const match = await bcrypt.compare(password, foundUser.password);
    if (match) {
        const role = foundUser.role;
        const accessToken = jwt.sign(
            {
                'userInfo': {
                    'username': foundUser.username,
                    'role': role
                }
            },
            process.env.ACCESS_TOKEN_SECRET,
            { expiresIn: '15m' }
        );
        const newRefreshToken = jwt.sign(
            { 'username': foundUser.username },
            process.env.REFRESH_TOKEN_SECRET,
            { expiresIn: '1d' }
        );

        let newRefreshTokenArray =
            !cookies?.jwt
                ? foundUser.refreshToken
                : foundUser.refreshToken.filter(rt => rt !== cookies.jwt);

        if (cookies?.jwt) {

            const refreshToken = cookies.jwt;
            const foundToken = await User.findOne({ refreshToken }).exec();
            if (!foundToken) {
                newRefreshTokenArray = [];
            }

            res.clearCookie('jwt', { httpOnly: true, sameSite: 'None', maxAge: 24 * 60 * 60 * 1000 });
        }
        foundUser.refreshToken = [...newRefreshTokenArray, newRefreshToken];
        const query = await foundUser.save();

        res.cookie('jwt', newRefreshToken, { httpOnly: true, sameSite: 'None', maxAge: 24 * 60 * 60 * 1000 });
        res.json({
            'success': `User ${username} is logged in!`,
            accessToken
        });
    } else {
        res.status(401).json({ 'message': 'unauthorized' });
    }
};

const handleSignup = async (req, res, next) => {
    const { username, password, mail, firstName, lastName, mobile } = req.body;
    if (!username || !password || !firstName || !lastName || !mobile) return res.status(400).json({ 'message': 'Bad request - Username and Password are required' });
    if (password.length < 8) return res.status(400).json({ 'message': 'password must have minimun length of 8 characters' });
    if (mobile.length !== 10) return res.status(400).json({ 'message': 'mobile must have length of 10 characters' });

    const User = require('../models/user');
    const duplicateUser = await User.findOne({ username }).exec();
    if (duplicateUser) return res.status(409).json({ 'message': 'Conflict - User already exists!' });
    const duplicateMail = await User.findOne({ mail }).exec();
    if (duplicateMail) return res.status(409).json({ 'message': 'Conflict - User already exists with this mail' });

    const regexUser = /^[A-Za-z][A-Za-z_0-9]{7,30}$/g;
    const regexMail = /^[a-zA-Z0-9-.]+@[a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)*$/gm;
    const validUser = regexUser.test(username);
    const validMail = regexMail.test(mail);
    if (!validUser) return res.status(406).json({ 'message': 'Not acceptable - Username should contain only alphabets or numbers or underscore and minimun 8 characters required' });
    if (!validMail) return res.status(406).json({ 'message': 'Not acceptable - Mail should be correctly formatted' });

    try {
        const pwdhash = await bcrypt.hash(password, 10);

        const query = await User.create({
            username,
            password: pwdhash,
            mail,
            firstName,
            lastName,
            mobile: parseInt(mobile),
        });
        await query.save();

        res.status(201).json({ 'success': 'Created - User created' });
    }
    catch (err) {
        next(err);
    }
};

const handleRefreshToken = async (req, res) => {
    const cookies = req.cookies;
    const { role } = req.params;
    if (!role) return res.status(400).json({ 'message': 'Bad request - role is required' });
    if (!['user', 'admin'].includes(role)) return res.status(400).json({ 'message': 'invalid role' });
    if (!cookies?.jwt) return res.status(401).json({ 'message': 'Bad request' });

    const refreshToken = cookies.jwt;
    res.clearCookie('jwt', { httpOnly: true, sameSite: 'Lax', maxAge: 24 * 60 * 60 * 1000 });

    const User = require('../models/' + role);
    const foundUser = await User.findOne({ refreshToken }).exec();

    if (!foundUser) {
        jwt.verify(
            refreshToken,
            process.env.REFRESH_TOKEN_SECRET,
            async (err, decoded) => {
                if (err) return res.status(403).json({ 'message': 'Forbidden' });
                const hackedUser = await User.findOne({ username: decoded.username }).exec();
                hackedUser.refreshToken = [];
                const query = await hackedUser.save();
            }
        )
        return res.status(403).json({ 'message': 'Forbidden' });
    }

    const newRefreshTokenArray = foundUser.refreshToken.filter(rt => rt !== refreshToken);

    jwt.verify(
        refreshToken,
        process.env.REFRESH_TOKEN_SECRET,
        async (err, decoded) => {
            if (err) {
                foundUser.refreshToken = [...newRefreshTokenArray];
                const query = await foundUser.save()
            }
            if (err || foundUser.username !== decoded.username) return res.status(403).json({ 'message': 'Forbidden' });
            const accessToken = jwt.sign(
                {
                    'userInfo': {
                        'id': foundUser._id,
                        'username': foundUser.username,
                        'role': role
                    }
                },
                process.env.ACCESS_TOKEN_SECRET,
                { expiresIn: '15m' }
            );

            const newRefreshToken = jwt.sign(
                { 'username': foundUser.username },
                process.env.REFRESH_TOKEN_SECRET,
                { expiresIn: '1d' }
            );
            foundUser.refreshToken = [...newRefreshTokenArray, newRefreshToken];
            const query = await foundUser.save();

            res.cookie('jwt', newRefreshToken, { httpOnly: true, sameSite: 'Lax', maxAge: 24 * 60 * 60 * 1000 }); //put secure:true

            res.json({ accessToken });
        }
    );
}

const handleLogout = async (req, res) => {
    const { role } = req.body;
    if (!role) return res.status(400).json({ 'message': 'Bad request - role is required' });
    if (!['user', 'admin'].includes(role)) return res.status(400).json({ 'message': 'invalid role' });

    const cookies = req.cookies;
    if (!cookies?.jwt) return res.status(204).json({ 'message': 'No content' });

    const refreshToken = cookies.jwt;
    const User = require('../models/' + role);
    const foundUser = await User.findOne({ refreshToken }).exec();
    if (!foundUser) {
        res.clearCookie('jwt', { httpOnly: true, sameSite: 'None', maxAge: 24 * 60 * 60 * 1000 });
        return res.status(204).json({ 'message': 'No content' });
    }

    foundUser.refreshToken = foundUser.refreshToken.filter(rt => rt !== refreshToken);;
    const query = await foundUser.save();

    res.clearCookie('jwt', { httpOnly: true, sameSite: 'None', maxAge: 24 * 60 * 60 * 1000 });
    res.status(204).json({ 'message': 'No content' });
};

const forgetPassword = async (req, res) => {
    const { mail, role } = req.body;
    if (!role) return res.status(400).json({ 'message': 'Bad request - role is required' });
    if (!['user', 'admin'].includes(role)) return res.status(400).json({ 'message': 'invalid role' });
    if (!mail || mail.length === 0) return res.status(400).json({ 'message': 'mail is required' });

    try {
        const User = require('../models/' + role);
        const user = await User.findOne({ mail });

        if (!user) {
            return res.status(404).send({ message: "User not found" });
        }

        const role = user.role;
        const token = jwt.sign({ userId: user._id, role }, process.env.ACCESS_TOKEN_SECRET, { expiresIn: "10m", });

        const transporter = nodemailer.createTransport({
            service: "gmail",
            auth: {
                user: process.env.EMAIL,
                pass: process.env.PASSWORD_APP_EMAIL,
            },
        });

        const mailOptions = {
            from: process.env.EMAIL,
            to: req.body.mail,
            subject: "Reset Password",
            html: `<h1>Reset Your Password</h1>
      <p>Click on the following link to reset your password:</p>
      <a href="${process.env.RESET_URL}">Reset password</a>
      <p>The link will expire in 10 minutes.</p>
      <p>If you didn't request a password reset, please ignore this email.</p>`,
        };

        transporter.sendMail(mailOptions, (err, info) => {
            if (err) {
                return res.status(500).send({ message: err.message });
            }
            res.status(200).json({ 'success': "Email sent", token });
        });
    } catch (err) {
        res.status(500).send({ message: err.message });
    }
};

const resetPassword = async (req, res) => {
    const { token, newPassword } = req.body;
    if (!token || token.length === 0) return res.status(400).json({ 'message': 'token is required' });
    if (!newPassword || newPassword.length === 0) return res.status(400).json({ 'message': 'password is required' });

    try {
        const decodedToken = jwt.verify(
            token,
            process.env.ACCESS_TOKEN_SECRET
        );

        if (!decodedToken) {
            return res.status(401).send({ message: "Invalid token" });
        }

        const role = decodedToken.role;
        const User = require('../models/' + role);
        const user = await User.findOne({ _id: decodedToken.userId });
        if (!user) {
            return res.status(401).send({ message: "no user found" });
        }

        if (newPassword.length < 8) return res.status(400).json({ 'message': 'password must have minimun length of 8 characters' });
        const password = await bcrypt.hash(newPassword, 10);

        user.password = password;
        await user.save();

        res.status(200).send({ success: "Password updated" });
    } catch (err) {
        res.status(500).send({ message: err.message });
    }
};

const handleContact = async (req, res) => {
    const { name, mobile, mail, find, message } = req.body;
    if (!name || name.length === 0 || !find || find.length === 0 || !message || message.length === 0) return res.status(400).json({ 'message': 'All details required' });
    if (mobile.toString().length !== 10) return res.status(400).json({ 'message': 'mobile must have length of 10 characters' });

    const regexMail = /^[a-zA-Z0-9-.]+@[a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)*$/gm;
    const validMail = regexMail.test(mail);
    if (!validMail) return res.status(406).json({ 'message': 'Not acceptable - Mail should be correctly formatted' });

    try {
        const query = await Contact.create({
            name,
            mobile,
            mail,
            find,
            message
        });

        await query.save();

        res.status(200).send({ success: "Successfully received message" });
    } catch (err) {
        res.status(500).send({ message: err.message });
    }
};

const handleNewsletter = async (req, res) => {
    const { mail } = req.body;

    const regexMail = /^[a-zA-Z0-9-.]+@[a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)*$/gm;
    const validMail = regexMail.test(mail);
    if (!validMail) return res.status(406).json({ 'message': 'Not acceptable - Mail should be correctly formatted' });

    try {
        const query = await Newsletter.create({
            mail,
        });

        await query.save();

        res.status(200).send({ success: "Successfully registered mail" });
    } catch (err) {
        res.status(500).send({ message: err.message });
    }
}

module.exports = {
    handleLogin,
    handleSignup,
    handleRefreshToken,
    handleLogout,
    forgetPassword,
    resetPassword,
    handleContact,
    handleNewsletter
};