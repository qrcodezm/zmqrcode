const express = require('express');
const router = express.Router();
const userController = require('../controller/userController');

router.post('/login$', userController.handleLogin);

router.post('/signup$', userController.handleSignup);

router.get('/refresh/:role$', userController.handleRefreshToken);

router.post('/logout$', userController.handleLogout);

router.post("/forget", userController.forgetPassword);

router.post("/reset", userController.resetPassword);

router.post('/contact', userController.handleContact);

router.post('/newsletter', userController.handleNewsletter);

module.exports = router;