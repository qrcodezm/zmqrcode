const express = require('express');
const router = express.Router();
const servicesController = require('../controller/servicesController');

router.post('/url$', servicesController.handleUrl);

module.exports = router;